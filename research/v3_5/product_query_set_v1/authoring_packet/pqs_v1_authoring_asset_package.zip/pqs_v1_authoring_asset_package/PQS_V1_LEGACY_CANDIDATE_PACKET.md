# Product Query Set v1 — Legacy Candidate Packet

以下问题是从历史项目文档中提取的 Legacy Candidate，仅作为第二阶段参考材料。它们不是经过批准的 Product Query，也不代表真实搜索日志。

Only provide this packet after Pass 1 independent drafting is complete.

## PQS_R_CAND_001

- Raw Query: 找出我收藏过的 Harness 相关内容。
- Source Type: actual_search_or_navigation_requirement
- Source Reference: `00_V3_RETRIEVAL_VERSION_BRIEF.md`, lines 74-76
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_002

- Raw Query: 哪些视频讨论了 Agent Memory 的上下文压缩？
- Source Type: actual_search_or_navigation_requirement
- Source Reference: `00_V3_RETRIEVAL_VERSION_BRIEF.md`, lines 78-79
- Existing Query Family: definition
- Multi-aspect: false

## PQS_R_CAND_003

- Raw Query: 最近收藏但还没看的 LangGraph 视频有哪些？
- Source Type: actual_search_or_navigation_requirement
- Source Reference: `00_V3_RETRIEVAL_VERSION_BRIEF.md`, lines 80-81
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_004

- Raw Query: 哪条视频在什么时间点提到了某个 GitHub 项目？
- Source Type: actual_search_or_navigation_requirement
- Source Reference: `00_V3_RETRIEVAL_VERSION_BRIEF.md`, lines 82-83
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_005

- Raw Query: 添加公开来源
- Source Type: explicit_product_use_requirement
- Source Reference: `docs/specs/2026-07-15-shiliu-v1.md`, line 138
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_006

- Raw Query: 立即同步
- Source Type: explicit_product_use_requirement
- Source Reference: `docs/specs/2026-07-15-shiliu-v1.md`, line 152
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_007

- Raw Query: 定时同步发现新视频或处理历史积压
- Source Type: explicit_product_use_requirement
- Source Reference: `docs/specs/2026-07-15-shiliu-v1.md`, line 166
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_008

- Raw Query: 精修快速版
- Source Type: explicit_product_use_requirement
- Source Reference: `docs/specs/2026-07-15-shiliu-v1.md`, line 179
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_009

- Raw Query: 这条内容是否值得完整处理？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 614
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_010

- Raw Query: 应该做简短摘要还是深度分析？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 615
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_011

- Raw Query: 教程、访谈、新闻、项目演示分别调用什么流程？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 616
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_012

- Raw Query: 字幕不足时是否需要抽关键帧？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 617
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_013

- Raw Query: 视频提到 GitHub 项目时是否读取 README？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 618
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_014

- Raw Query: 内容与已有知识库是否重复或冲突？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 619
- Existing Query Family: evaluation_or_quality
- Multi-aspect: false

## PQS_R_CAND_015

- Raw Query: 应该生成 Markdown、对比表、知识卡片还是视频？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 620
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_016

- Raw Query: 失败后应该换哪个 Provider，还是请求人工处理？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 621
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_017

- Raw Query: bilibili-cli 是否足以承担拾流的 B 站 Source Adapter？哪些能力可以直接借用，哪些必须由拾流自己实现？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1210
- Existing Query Family: natural_multi_aspect
- Multi-aspect: true

## PQS_R_CAND_018

- Raw Query: Source Adapter 怎么定义？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1512
- Existing Query Family: definition
- Multi-aspect: false

## PQS_R_CAND_019

- Raw Query: Content Item 最小 Schema 是什么？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1513
- Existing Query Family: definition
- Multi-aspect: false

## PQS_R_CAND_020

- Raw Query: 如何识别新增？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1514
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_021

- Raw Query: 处理状态需要多复杂？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1515
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_022

- Raw Query: 字幕 Provider 如何降级？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1516
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_023

- Raw Query: 摘要输出格式是什么？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1517
- Existing Query Family: definition
- Multi-aspect: false

## PQS_R_CAND_024

- Raw Query: 文件与数据库如何分工？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1518
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_025

- Raw Query: 失败如何保留证据？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1519
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_026

- Raw Query: 拾流 V0 只监控一个收藏夹，还是支持多个收藏夹？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1563
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_027

- Raw Query: “新增”以首次扫描时间、收藏时间还是本地差集定义？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1564
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_028

- Raw Query: 是否处理收藏夹已有历史视频，还是只处理启用后的新增？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1565
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_029

- Raw Query: 第一版摘要需要什么固定结构？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1566
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_030

- Raw Query: 是否保存完整字幕和时间戳？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1567
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_031

- Raw Query: 长视频采用何种分段策略？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1568
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_032

- Raw Query: 没有字幕时是否立即 ASR，还是进入待处理列表？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1569
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_033

- Raw Query: 第一版是否需要 SQLite，还是先用轻量状态文件？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1570
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_034

- Raw Query: 文件目录如何组织？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1571
- Existing Query Family: how_to_or_process
- Multi-aspect: false

## PQS_R_CAND_035

- Raw Query: 是否需要保留原始 API 响应作为证据？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1572
- Existing Query Family: evaluation_or_quality
- Multi-aspect: false

## PQS_R_CAND_036

- Raw Query: 第一版是否必须完全自动运行？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1573
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_037

- Raw Query: 是否需要本地查看页，还是 Markdown 足够？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1574
- Existing Query Family: comparison_or_tradeoff
- Multi-aspect: false

## PQS_R_CAND_038

- Raw Query: 哪些失败应自动重试，哪些应停止？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1575
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_039

- Raw Query: 是否需要维护摘要版本和 Prompt 版本？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1576
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false

## PQS_R_CAND_040

- Raw Query: 后续多平台统一 Schema 应预留到什么程度？
- Source Type: human_authored_project_note
- Source Reference: `拾流_Shiliu_完整项目上下文与当前行动.md`, line 1577
- Existing Query Family: decision_or_troubleshooting
- Multi-aspect: false
